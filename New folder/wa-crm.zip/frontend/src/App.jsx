import { Routes, Route } from "react-router-dom";
import NavRail from "./components/NavRail.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import ChatCRM from "./pages/ChatCRM.jsx";
import SmartLeads from "./pages/SmartLeads.jsx";
import Properties from "./pages/Properties.jsx";
import Insights from "./pages/Insights.jsx";
import Campaigns from "./pages/Campaigns.jsx";
import Templates from "./pages/Templates.jsx";

export default function App() {
  return (
    <div className="app-shell">
      <NavRail />
      <main className="main-content">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/chats" element={<ChatCRM />} />
          <Route path="/leads" element={<SmartLeads />} />
          <Route path="/properties" element={<Properties />} />
          <Route path="/campaigns" element={<Campaigns />} />
          <Route path="/templates" element={<Templates />} />
          <Route path="/insights" element={<Insights />} />
        </Routes>
      </main>
    </div>
  );
}
